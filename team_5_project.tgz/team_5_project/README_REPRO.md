# ScanForge Paper Reproduction Package (`team_5_project`)

Self-contained bundle for reproducing experiments in `paper/main.tex`:
progressive residual ATPG (T=1→T=2→T=4), five ablation experiments, memory
usage (VmPeak), and non-scan ratio sweep (5%–20%).

**Paper PDF:** `paper/main.pdf` (compiled from `paper/main.tex`)

## Prerequisites

| Tool | Purpose |
|------|---------|
| g++, make | Build FAN_ATPG (prebuilt `bin/opt/fan` included) |
| Python 3 | All experiment runners |
| Yosys | Regenerate ITC'99 netlists (optional; `mod_netlist/` included) |
| OpenSTA (`sta`) | Regenerate slack masks (optional; `masks/` included) |
| curl | Download ISCAS TTU netlists if missing |

```bash
export PATH=$HOME/local/bin:$PATH   # yosys, sta if installed locally
```

## One-command reproduction

```bash
cd team_5_project
./run              # build + smoke + Exp 1–5 + ratio sweep + B2
./run help         # all commands and options
```

### `./run` commands

| Command | Action |
|---------|--------|
| `all` (default) | build → smoke → experiments → ratio → b2 |
| `build` | compile `FAN_ATPG/bin/opt/fan` |
| `smoke` | quick b03 @10% ATPG check |
| `netlists` | regenerate ITC'99 + ISCAS'89 netlists (needs yosys) |
| `masks` | regenerate OpenSTA slack masks (needs sta) |
| `experiments` | Exp 1–5 @ 10% → `results/exp*.csv` |
| `ratio` | 5/10/15/20% sweep → `results/ratio_sweep/` |
| `b2` | ISCAS'89 full-scan baseline |
| `figures` | regenerate `docs/figures/` (needs matplotlib) |

Options: `--skip-build`, `--regen-netlists`, `--regen-masks`, `--with-figures`, `--jobs N`

## Manual steps (equivalent to `./run all`)

```bash
./run build && ./run smoke && ./run experiments && ./run ratio && ./run b2
```

## Key paths

| Path | Contents |
|------|----------|
| `scripts/run_progressive_residual.py` | Core T=1→T=2→T=4 pipeline + memory |
| `scripts/run_experiment_sweep.py` | Exp 1–5 @ 10% |
| `scripts/run_ratio_experiment_sweep.py` | Ratio sweep |
| `scripts/gen_nonscan_masks.sh` | OpenSTA slack → masks |
| `FAN_ATPG/pkg/` | ATPG engine source (Two-Phase, ablation flags) |
| `FAN_ATPG/mod_netlist/` | Synthesized benchmark netlists |
| `masks/` | Non-scan masks x5/x10/x15/x20 |
| `results/exp*.csv` | Reference ablation outputs |
| `results/ratio_sweep/` | Reference ratio-sweep outputs |
| `paper/main.tex` | Paper source |
| `paper/main.pdf` | Compiled paper PDF |

## Environment variables

- `ATPG_WALL_TIMEOUT` — per-stage wall timeout (default 3600s)
- `ATPG_PER_TARGET_TIMEOUT` — per-target timeout (default 0 = off)
- `ATPG_T1_BACKTRACK_LIMIT` — T=1 backtrack limit (default 800; Exp 3 uses 5000)

## ITC'99 B2 full-scan

`results/phase_d_fullscan_dataset.csv` is included as reference. Regenerate
with the same pattern as `scripts/run_fullscan_baseline_iscas89.py` (full-scan,
frame 1, no `set_nonscan_ff`).
