#!/usr/bin/env bash
# Package everything needed to reproduce paper/main.tex experiments.
# Usage: bash scripts/package_paper_repro.sh [output_dir]
set -euo pipefail

SCRIPT_DIR="$(cd -- "${BASH_SOURCE[0]%/*}" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
OUT="${1:-$REPO_ROOT/paper_repro_package}"

echo "Packaging paper reproduction bundle -> $OUT"
rm -rf "$OUT"
mkdir -p "$OUT"

rsync -a \
  --exclude='__pycache__/' \
  --exclude='*.pyc' \
  --exclude='archive/' \
  "$REPO_ROOT/scripts/" "$OUT/scripts/"

rsync -a \
  --exclude='*.aux' --exclude='*.log' --exclude='*.out' \
  --exclude='*.bbl' --exclude='*.blg' --exclude='main.pdf' \
  "$REPO_ROOT/paper/" "$OUT/paper/"

mkdir -p "$OUT/docs"
rsync -a "$REPO_ROOT/docs/figures/" "$OUT/docs/figures/"
rsync -a "$REPO_ROOT/docs/experiment_list.md" "$OUT/docs/"
rsync -a "$REPO_ROOT/docs/spec.md" "$OUT/docs/"

rsync -a "$REPO_ROOT/itc99_rtl/" "$OUT/itc99_rtl/" --exclude='.git'
rsync -a "$REPO_ROOT/iscas89_rtl/" "$OUT/iscas89_rtl/"

rsync -a "$REPO_ROOT/masks/" "$OUT/masks/"

mkdir -p "$OUT/results/residual_faults" "$OUT/results/fault_status"
for f in exp1_baseline.csv exp2_two_phase.csv exp3_uniform_T1.csv \
         exp4_enhanced_backtrace.csv exp5_static_learning.csv \
         phase_d_fullscan_dataset.csv iscas89_fullscan_baseline.csv; do
  if [[ -f "$REPO_ROOT/results/$f" ]]; then
    cp "$REPO_ROOT/results/$f" "$OUT/results/"
  fi
done
rsync -a "$REPO_ROOT/results/ratio_sweep/" "$OUT/results/ratio_sweep/" 2>/dev/null || true
for log in sweep_log.txt ratio_sweep_log.txt; do
  [[ -f "$REPO_ROOT/results/$log" ]] && cp "$REPO_ROOT/results/$log" "$OUT/results/"
done

# FAN_ATPG: source, binary, netlists, techlib (skip bulky regenerated rpt/)
mkdir -p "$OUT/FAN_ATPG"
for item in Makefile rule.mk README.md ATPG_UserGuide.pdf; do
  [[ -e "$REPO_ROOT/FAN_ATPG/$item" ]] && rsync -a "$REPO_ROOT/FAN_ATPG/$item" "$OUT/FAN_ATPG/"
done
rsync -a "$REPO_ROOT/FAN_ATPG/include/" "$OUT/FAN_ATPG/include/"
rsync -a "$REPO_ROOT/FAN_ATPG/pkg/" "$OUT/FAN_ATPG/pkg/" \
  --exclude='*.o' --exclude='*.d' --exclude='*.exe'
rsync -a "$REPO_ROOT/FAN_ATPG/utility/" "$OUT/FAN_ATPG/utility/"
rsync -a "$REPO_ROOT/FAN_ATPG/techlib/" "$OUT/FAN_ATPG/techlib/"
rsync -a "$REPO_ROOT/FAN_ATPG/mod_netlist/" "$OUT/FAN_ATPG/mod_netlist/"
rsync -a "$REPO_ROOT/FAN_ATPG/bin/" "$OUT/FAN_ATPG/bin/"
mkdir -p "$OUT/FAN_ATPG/script/fanScripts" "$OUT/FAN_ATPG/rpt" "$OUT/FAN_ATPG/pat"
rsync -a "$REPO_ROOT/FAN_ATPG/script/" "$OUT/FAN_ATPG/script/" \
  --exclude='fanScripts/*' 2>/dev/null || true

# OpenSTA expects typical.lib; repo uses NangateOpenCellLibrary.v
if [[ ! -f "$OUT/FAN_ATPG/techlib/NangateOpenCellLibrary_typical.lib" ]]; then
  ln -sf NangateOpenCellLibrary.v "$OUT/FAN_ATPG/techlib/NangateOpenCellLibrary_typical.lib"
fi

cp "$REPO_ROOT/AGENTS.md" "$OUT/AGENTS.md" 2>/dev/null || true

# Reproduction README (written by packager into bundle)
cat > "$OUT/README_REPRO.md" <<'EOF'
# ScanForge Paper Reproduction Package

Self-contained bundle for reproducing experiments in `paper/main.tex`:
progressive residual ATPG (T=1→T=2→T=4), five ablation experiments, memory
usage (VmPeak), and non-scan ratio sweep (5%–20%).

## Prerequisites

| Tool | Purpose |
|------|---------|
| g++, make | Build FAN_ATPG (prebuilt `bin/opt/fan` included) |
| Python 3 | All experiment runners |
| Yosys | Regenerate ITC'99 netlists (optional; `mod_netlist/` included) |
| OpenSTA (`sta`) | Regenerate slack masks (optional; `masks/` included) |
| curl | Download ISCAS TTU netlists if missing |

```bash
export PATH=$HOME/local/bin:$PATH   # yosys, sta if installed locally
```

## Quick verify (prebuilt binary + existing masks)

```bash
cd paper_repro_package
ATPG_WALL_TIMEOUT=3600 python3 scripts/run_progressive_residual.py \
  --circuit b03 --ratio 0.10 \
  --nonscan "$(tr '\n' ' ' < masks/b03_x10.mask)" \
  --t1-two-phase off --t2-two-phase off --t4-two-phase off \
  --per-target-timeout 0
```

## Full reproduction order

```bash
# 1. Build FAN (or use included binary)
cd FAN_ATPG && make -j$(nproc) bin/opt/fan && cd ..

# 2. Regenerate netlists (optional)
bash scripts/build_itc99_netlists.sh
bash scripts/synth_iscas89.sh

# 3. Regenerate masks (optional)
bash scripts/gen_nonscan_masks.sh

# 4. Ablation Exp 1–5 @ 10% (memory columns included)
ATPG_WALL_TIMEOUT=3600 python3 scripts/run_experiment_sweep.py

# 5. Ratio sweep 5/10/15/20%
ATPG_WALL_TIMEOUT=3600 python3 scripts/run_ratio_experiment_sweep.py

# 6. ISCAS'89 full-scan B2
python3 scripts/run_fullscan_baseline_iscas89.py

# 7. Paper figures
python3 scripts/generate_figures.py
```

## Key paths

| Path | Contents |
|------|----------|
| `scripts/run_progressive_residual.py` | Core T=1→T=2→T=4 pipeline + memory |
| `scripts/run_experiment_sweep.py` | Exp 1–5 @ 10% |
| `scripts/run_ratio_experiment_sweep.py` | Ratio sweep |
| `scripts/gen_nonscan_masks.sh` | OpenSTA slack → masks |
| `FAN_ATPG/pkg/` | ATPG engine source (Two-Phase, ablation flags) |
| `FAN_ATPG/mod_netlist/` | Synthesized benchmark netlists |
| `masks/` | Non-scan masks x5/x10/x15/x20 |
| `results/exp*.csv` | Reference ablation outputs |
| `results/ratio_sweep/` | Reference ratio-sweep outputs |
| `paper/main.tex` | Paper source |

## Environment variables

- `ATPG_WALL_TIMEOUT` — per-stage wall timeout (default 3600s)
- `ATPG_PER_TARGET_TIMEOUT` — per-target timeout (default 0 = off)
- `ATPG_T1_BACKTRACK_LIMIT` — T=1 backtrack limit (default 800; Exp 3 uses 5000)

## ITC'99 B2 full-scan

`results/phase_d_fullscan_dataset.csv` is included as reference. Regenerate
with the same pattern as `scripts/run_fullscan_baseline_iscas89.py` (full-scan,
frame 1, no `set_nonscan_ff`).
EOF

# Manifest
find "$OUT" -type f | LC_ALL=C sort > "$OUT/MANIFEST.txt"
COUNT=$(wc -l < "$OUT/MANIFEST.txt")
SIZE=$(du -sh "$OUT" | cut -f1)
echo "Done: $COUNT files, total size $SIZE"
echo "Bundle: $OUT"
